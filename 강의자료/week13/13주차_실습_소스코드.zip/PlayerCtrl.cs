﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerCtrl : MonoBehaviour {

	public Animation DamageEffect;
	public Text ScoreText;
	public Text HPText;
	private int HP;
	private int Score;

	// Use this for initialization
	void Start () {
		HP = 100;
		ScoreText.text = "Score : " + Score;
		HPText.text = "HP : " + HP;
	}

	public void ApplyDamage (int Damage)
	{
		DamageEffect.Play ();
		this.HP -= Damage;
		HPText.text = "HP : " + this.HP;
		if (HP <= 0) {
			Application.LoadLevel (0);
		}
	}

	public void ScoreUP(int Score)
	{
		this.Score += Score;
		ScoreText.text = "Score : " + this.Score;
	}

	// Update is called once per frame
	void Update () {
		
	}
}
