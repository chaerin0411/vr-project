﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyCtrl : MonoBehaviour {

	public GameObject HitEffect;
	private int HP;
	private GameObject Player;
	private NavMeshAgent navMesh;
	private Animator ani;
	private bool isAttack;

	// Use this for initialization
	void Start () {
		HP = 100;
		Player = GameObject.Find ("Player");
		navMesh = GetComponent<NavMeshAgent> ();
		ani = GetComponent<Animator> ();
		navMesh.destination = Player.transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		float Distance = Vector3.Distance (Player.transform.position,
			                 transform.position);
		if (Distance <= 2.0f) {
			navMesh.Stop ();
			if (isAttack == false) {
				ani.SetBool ("Idle", true);
				StartCoroutine (Attack ());
			}
		}
	}

	IEnumerator Attack()
	{
		isAttack = true;
		yield return new WaitForSeconds (3.0f);
		ani.SetBool ("Attack", true);
		yield return new WaitForSeconds (0.5f);
		Player.GetComponent<PlayerCtrl>().ApplyDamage (10);
		isAttack = false;
		ani.SetBool ("Attack", false);
	}

	void OnCollisionEnter(Collision coll)
	{
		if (coll.gameObject.CompareTag ("Bullet")) {
			GameObject hitEffect = Instantiate (HitEffect, coll.transform.position,
				coll.transform.rotation);			
			Destroy (coll.gameObject);
			Destroy (hitEffect, 2.0f);
			HP -= 10;
			if (HP <= 0) {
				Destroy (gameObject);
				Player.GetComponent<PlayerCtrl>().ScoreUP (100);
			}
		}
	}
}
